/////////////////////////////////////////////////////////////////////////////
// Name:        class_help.h
// Purpose:     Help classes group docs
// Author:      wxWidgets team
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

/**

@defgroup group_class_help Help
@ingroup group_class

Classes for loading and displaying help manuals or help informations in general.

*/

